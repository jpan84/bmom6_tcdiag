from xoverturning.moc import calcmoc
import numpy as np
import xarray as xr # requires >= 0.15.1
import pandas as pd
from dask.diagnostics import ProgressBar
import matplotlib.pyplot as plt

ds_rho2 = xr.open_mfdataset('/glade/derecho/scratch/jpan/archive/b.e23.BMOM.ne30np4_sx0.66av1.aqua.production.250411_unseed/ocn/hist/b.e23.BMOM.ne30np4_sx0.66av1.aqua.production.250411_unseed.mom6.rho2cust_avg.*.nc')
static = xr.open_dataset('/glade/derecho/scratch/jpan/b.e23.BMOM.ne30np4_sx0.66av1.aqua.production.250411_seed1x1/run/b.e23.BMOM.ne30np4_sx0.66av1.aqua.production.250411_seed1x1.mom6.static.nc', drop_variables='time')

print(ds_rho2)
print(ds_rho2.time.values)
print(static)
#print(static.time.values)

moc_rho2 = calcmoc(ds_rho2, dsgrid=static, vertical='rho2')
with ProgressBar():
   moc_rho2_mean = moc_rho2.mean('time').load()

fig, ax = plt.subplots(figsize=(10,5))
moc_rho2_mean.sel(rho2_i=slice(1028,None)).plot(ax=ax, yincrease=False,vmin=-30,vmax=30,cmap='RdBu_r',
                                                  cbar_kwargs={'ticks': np.arange(-30,35,5)})
moc_rho2_mean.sel(rho2_i=slice(1028,None))\
    .plot.contour(ax=ax, yincrease=False, levels=np.concatenate([np.arange(-30,0,5),np.arange(5,35,5)]),
                  colors='k', linewidths=1)
plt.show()
